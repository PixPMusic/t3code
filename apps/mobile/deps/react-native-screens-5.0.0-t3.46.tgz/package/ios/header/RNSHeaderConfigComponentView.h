#pragma once

#import "RNSHeaderConfigDataProviding.h"
#import "RNSHeaderCoordinator.h"
#import "RNSHeaderEventsDelegate.h"
#import "RNSHeaderItemInvalidationDelegate.h"
#import "RNSImageLoading.h"
#import "RNSReactBaseView.h"
#import "RNSViewFrameChangeDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface RNSHeaderConfigComponentView : RNSReactBaseView <
                                              RNSViewFrameChangeDelegate,
                                              RNSHeaderConfigDataProviding,
                                              RNSHeaderItemInvalidationDelegate,
                                              RNSHeaderEventsDelegate,
                                              RNSImageLoading>

@property (nonatomic, readonly, nullable) NSString *title;
@property (nonatomic, readonly, nullable) NSString *subtitle;
@property (nonatomic, readonly) BOOL hidden;
@property (nonatomic, readonly, nullable) UIColor *tintColor;
@property (nonatomic, readonly) BOOL backButtonHidden;
#if RNS_IPHONE_OS_VERSION_AVAILABLE(16_0) && !TARGET_OS_TV
@property (nonatomic, readonly) UINavigationItemStyle navigationItemStyle API_AVAILABLE(ios(16.0));
#endif
@property (nonatomic, readonly, nullable) NSString *largeTitle;
@property (nonatomic, readonly, nullable) NSString *largeSubtitle;
@property (nonatomic, readonly) BOOL largeTitleEnabled;
@property (nonatomic, readonly, nullable) NSString *prompt;
#if RNS_IPHONE_OS_VERSION_AVAILABLE(27_0)
@property (nonatomic, readonly) UIBarMinimizationBehavior minimizationBehavior API_AVAILABLE(ios(27.0));
@property (nonatomic, readonly) UIBarMinimizationRestorationBehavior restorationBehavior API_AVAILABLE(ios(27.0));
#endif // Check for iOS >= 27
@property (nonatomic, readonly, nullable) NSString *backButtonTitle;
@property (nonatomic, readonly) UINavigationItemBackButtonDisplayMode backButtonDisplayMode;
@property (nonatomic, readonly) BOOL backButtonMenuEnabled;
@property (nonatomic, readonly, nullable) RNSHeaderMenuData *titleMenu;
@property (nonatomic, readonly, nullable) UINavigationBarAppearance *standardAppearance;
@property (nonatomic, readonly, nullable) UINavigationBarAppearance *scrollEdgeAppearance;
@property (nonatomic, readonly) NSArray<id> *children;

@property (nonatomic, weak, nullable) RNSHeaderCoordinator *headerCoordinator;

- (void)resetProps;

@end

NS_ASSUME_NONNULL_END

#pragma mark - Hidden from Swift

#if defined(__cplusplus)

#import <react/renderer/components/rnscreens/RNSHeaderConfigComponentDescriptor.h>

@interface RNSHeaderConfigComponentView ()

- (facebook::react::RNSHeaderConfigShadowNode::ConcreteState::Shared)state;

@end

#endif // defined(__cplusplus)
